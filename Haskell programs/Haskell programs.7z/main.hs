import qualified A.BinTree as BT

main = print $ BT.heightTree $ BT.listToTree [1..10]
